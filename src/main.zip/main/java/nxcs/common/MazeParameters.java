package nxcs.common;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MazeParameters {

    public int totalTrailCount;
    public int finalStateUpperBound;
    public int resultInterval;
    public String logFolder;

    public String fileTimestampFormat;

    public MazeParameters(){

        SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("yyyyMMddHHmm");
        this.fileTimestampFormat = dateformatyyyyMMdd.format(new Date());
        this.resultInterval = 600;
    }
}
