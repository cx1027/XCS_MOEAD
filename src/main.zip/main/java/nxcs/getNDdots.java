package nxcs;

public class getNDdots {

}
